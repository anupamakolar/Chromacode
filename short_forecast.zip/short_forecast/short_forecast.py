import requests
import json
import sys

#Function to get the forecast based on latitude and longitude
def get_forecast (latstr,lonstr):
    #Convert the latitude and longitude values from string to float
    lat=float(latstr)
    lon=float(lonstr)
    #Send the API request to get the weather forecast based on latitude and longitude
    res = requests.get(f"https://api.weather.gov/points/{lat},{lon}")
    #Return the request response 
    return res

# main code 
#Get the Initial forecast from "weather.gov" based on the parameters
first_forecast = get_forecast(sys.argv[1],sys.argv[2])
#Get the link for the forecasts
mylink = first_forecast.json()['properties']['forecast']
#Send the API request to get the forecast details
linkres = requests.get(mylink)
#Extract the ShortForecast object for today/tonight
obj = linkres.json()['properties']['periods'][0]['shortForecast']
# create a formatted string of the Python JSON object
text = json.dumps(obj, sort_keys=True, indent=4)
#Output the Short Forecast as required
print(f"Short Forecast for {sys.argv[1]}, {sys.argv[2]} is:", text)

