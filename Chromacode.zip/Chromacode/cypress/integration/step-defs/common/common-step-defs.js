import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

//The common step definitions are stored in this file
//Using the variable for the actual link for convenience and reusability
const googlePage = "https://www.google.com"

//Browse to google.com
Given('I visit the google page', () => {
    cy.visit(googlePage);
});

//Assert that we are in the correct page
Then('I should be on the Google page', () => {
    cy.url().should('include', 'google');
    cy.contains('Google');
});


