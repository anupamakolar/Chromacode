import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

//Setup screenshot defaults
Cypress.Screenshot.defaults({
  capture: 'runner',})

//Click the `I'm Feeling Lucky` button
 Then ('I click the Feeling Lucky button', () => {
     cy.xpath('//*[@id="gbqfbb"]').click();
     //Assert that the button is clicked
     cy.contains('Feeling');
     //Click again to actually go to the first page selected
     cy.xpath('/html/body / div[1] / div[3] / form / div[1] / div[1] / div[3] / center / div').click();
 });

 //Screen shot the results. 
//The result is stored in the ..screenshots/features/exercise1.feature folder
 Then('I take a screenshot', () => {
    cy.screenshot('Exercise1_Results');
 });

