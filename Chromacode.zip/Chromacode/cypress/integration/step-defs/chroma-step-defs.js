import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

//Setup screenshot defaults
Cypress.Screenshot.defaults({
  capture: 'runner',})

// Enter "chromacode cloud" into the search entry text box
When('I enter search entry as {string}', (entry) => {
    cy.get('input[name="q"]').clear().type(entry);
});

//Click the`Google Search` button
When('I click the Google Search button', () => {
    cy.get('input[value="Google Search"]').first().click();
    cy.contains('chromacode');
});

//Locate the result that points to`chromacodecloud.com`
When('I get a list of chromacode entries',() => {
    cy.get('#search a')
    .filter(':contains("https://chromacodecloud.com")')
      .invoke('attr', 'href')
      .then(href => console.log(href));
    });

//Point the mouse to `chromacodecloud.com`
Then('I find the entry for {string}', (result) => {
cy.xpath('//*[@id="rso"]/div[10]/div/div/div/div[1]/a').trigger('mouseover');
}); 

 //Screen shot the results. 
//The result is stored in the ..screenshots/features/exercise2.feature folder
Then('I take a screen shot', () => {
    cy.screenshot('Exercise2_Results');
});
